# Dispatch Test Report (test-workflows)

## Run Log

- Date:
- Caller run URL:
- Target run URL:
- Inputs received:
- Async behavior confirmed (caller did not wait): yes/no

## Failure Cases

- Missing stacks validation:
- Permission failure (`actions: write` removed):
- Wrong workflow name/ref dispatch:

## Notes

- Fill this file with evidence links after each test run.

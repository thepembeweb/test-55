# test-workflows

Minimal workflow harness for dispatch-atlas-search-sync behavior testing.

## Workflows

- `.github/workflows/deploy.yml`: simulates deploy completion and asynchronously dispatches target workflow.
- `.github/workflows/atlas-search-index-sync.yml`: target workflow that validates and records dispatched inputs.

## Manual test

1. Trigger `Deploy (Test Workflows)` with:
   - `environment=dev`
   - `stacks=issue`
   - `accountId=123456789012`
   - `deploymentId=test-run-1`
2. Confirm a new run appears for `Atlas Search Index Sync (Test)`.
3. Validate summary and artifact `atlas-sync-inputs-<run_id>` in target run.

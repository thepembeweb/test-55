# Dispatch Test Report (test-cdk)

## Cross-Repo Chain Evidence

- Date:
- test-cdk caller run URL:
- test-workflows deploy run URL:
- test-workflows atlas-sync run URL:
- Inputs propagated correctly: yes/no
- Async behavior confirmed: yes/no

## Failure Cases

- Missing stacks validation:
- Permission failure (`actions: write` removed):
- Wrong target repo/workflow name:

## Notes

- Fill this file with evidence links after each run.

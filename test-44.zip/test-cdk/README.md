# test-cdk

Minimal cross-repo caller for dispatch-atlas-search-sync test flow.

## Workflow

- `.github/workflows/deploy.yml`: dispatches `test-workflows/.github/workflows/deploy.yml` using `gh api` and `github.token`.

## Manual test

1. Trigger `Deploy (Test CDK)` with:
   - `environment=dev`
   - `stacks=issue`
   - `accountId=123456789012`
   - `deploymentId=test-chain-1`
2. Confirm run appears in `test-workflows` for `Deploy (Test Workflows)`.
3. Confirm that run then dispatches `Atlas Search Index Sync (Test)` asynchronously.
